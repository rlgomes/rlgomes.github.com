'''
Created on Jan 22, 2011

@author: rlgomes
'''
from perf import track 

@track
def i(msg):
    print("I: %s" % msg)

@track
def e(msg):
    print("E: %s" % msg)

@track
def d(msg):
    print("D: %s" % msg)

@track
def w(msg):
    print("W: %s" % msg)
