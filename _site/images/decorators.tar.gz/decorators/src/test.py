'''
Created on Jan 22, 2011

@author: rlgomes
'''

import logger

logger.i("just a message")
logger.e("oh crap!")
logger.d("debug some stuff")
logger.w("you should have a look a this")