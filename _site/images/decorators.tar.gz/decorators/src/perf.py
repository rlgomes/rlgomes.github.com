'''
Created on Jan 22, 2011

@author: rlgomes
'''
import time

global DEBUG
DEBUG = False

def track(f):
    
    global DEBUG
    
    if ( DEBUG ):
        def new_f(*args, **kwargs):
            t = time.time()*1000
            ret = f(*args, **kwargs)
            dur = (time.time() * 1000) - t
            name = f.__name__
            print("%s executed in %dms" % (name, dur))
            return ret
        
        return new_f
    else: 
        return f